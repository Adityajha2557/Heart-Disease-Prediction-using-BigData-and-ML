from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("CombinedHeartCheck").getOrCreate()

src = "file:///D:/Big Data Projecr/datasets/heart_statlog_cleveland_hungary_final.csv"
df = spark.read.csv(src, header=True, inferSchema=True)

print("Dataset loaded successfully!")
df.printSchema()
df.show(5, truncate=False)
