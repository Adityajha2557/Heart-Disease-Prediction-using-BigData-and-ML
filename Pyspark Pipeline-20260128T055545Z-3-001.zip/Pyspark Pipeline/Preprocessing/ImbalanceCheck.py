
print(f"Total rows: {df.count()}")
print(f"Total columns: {len(df.columns)}")


print("Columns:", df.columns)


target_col = df.columns[-1]  
print(f"Target column: {target_col}")
df.groupBy(target_col).count().show()
