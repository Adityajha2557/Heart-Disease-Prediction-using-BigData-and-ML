from pyspark.sql import functions as F


print("Missing value check:")
for col in df.columns:
    null_count = df.filter(F.col(col).isNull()).count()
    print(f"{col}: {null_count} nulls")


print("Data types:")
for name, dtype in df.dtypes:
    print(f"{name}: {dtype}")
