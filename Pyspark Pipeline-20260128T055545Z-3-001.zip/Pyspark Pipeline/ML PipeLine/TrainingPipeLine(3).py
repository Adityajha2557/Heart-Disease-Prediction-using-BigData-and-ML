from pyspark.ml.classification import MultilayerPerceptronClassifier

input_dim = len(feature_cols)
print(f"Input dimension: {input_dim}")


mlp = MultilayerPerceptronClassifier(
    featuresCol="scaled_features", 
    labelCol="target",
    layers=[input_dim, 20, 10, 2],  # 4-layer network
    maxIter=200,
    seed=42
)

models = {
    "LogisticRegression": lr.fit(train),
    "RandomForest": rf.fit(train),
    "GBT": gbt.fit(train),
    "MLP_Neural_Network": mlp.fit(train)
}

print("All 4 models trained successfully!")
