from pyspark.ml import Pipeline
from pyspark.ml.feature import VectorAssembler, StandardScaler
from pyspark.ml.classification import LogisticRegression, RandomForestClassifier, GBTClassifier


feature_cols = [c for c in df.columns if c != 'target']
print("Feature columns:", feature_cols)


assembler = VectorAssembler(inputCols=feature_cols, outputCol="features")
scaler = StandardScaler(inputCol="features", outputCol="scaled_features", withMean=True, withStd=True)


prep_pipeline = Pipeline(stages=[assembler, scaler])
data = prep_pipeline.fit(df).transform(df)


train, test = data.randomSplit([0.8, 0.2], seed=42)

print(f"Train: {train.count()}, Test: {test.count()}")
