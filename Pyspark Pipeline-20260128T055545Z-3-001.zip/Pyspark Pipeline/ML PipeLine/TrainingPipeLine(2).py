
lr = LogisticRegression(featuresCol="scaled_features", labelCol="target", maxIter=100)
rf = RandomForestClassifier(featuresCol="scaled_features", labelCol="target", numTrees=100, seed=42)
gbt = GBTClassifier(featuresCol="scaled_features", labelCol="target", maxIter=100, seed=42)

models = {
    "LogisticRegression": lr.fit(train),
    "RandomForest": rf.fit(train),
    "GBT": gbt.fit(train)
}

print("Models trained successfully!")
