# Print the complete results table (fix the syntax error)
print("\n" + "="*80)
print("🫀 HEART DISEASE PREDICTION RESULTS 🫀")
print("="*80)
print(f"{'Model':<20} {'AUC':<8} {'AUPR':<8} {'Accuracy':<10} {'F1-Score':<8}")
print("-"*80)

for name, auc, aupr, acc, f1 in sorted(results, key=lambda x: x[3], reverse=True):
    print(f"{name:<20} {auc:<8.4f} {aupr:<8.4f} {acc:<10.4f} {f1:<8.4f}")

print("="*80)
print(f"🏆 BEST MODEL: {best_model[0]} with {best_model[3]:.2%} accuracy!")
