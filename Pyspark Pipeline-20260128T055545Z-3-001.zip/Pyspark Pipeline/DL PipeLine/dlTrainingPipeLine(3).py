from pyspark.ml.evaluation import BinaryClassificationEvaluator, MulticlassClassificationEvaluator


auc_evaluator = BinaryClassificationEvaluator(labelCol="target", rawPredictionCol="rawPrediction", metricName="areaUnderROC")
aupr_evaluator = BinaryClassificationEvaluator(labelCol="target", rawPredictionCol="rawPrediction", metricName="areaUnderPR") 
acc_evaluator = MulticlassClassificationEvaluator(labelCol="target", predictionCol="prediction", metricName="accuracy")
f1_evaluator = MulticlassClassificationEvaluator(labelCol="target", predictionCol="prediction", metricName="f1")

print("📊 EVALUATING ALL DEEP LEARNING MODELS:")
print("="*80)


dl_results = []
for name, model in dl_models.items():
    print(f"Evaluating {name}...")
    predictions = model.transform(test)
    
    auc_score = auc_evaluator.evaluate(predictions)
    aupr_score = aupr_evaluator.evaluate(predictions)
    acc_score = acc_evaluator.evaluate(predictions)
    f1_score = f1_evaluator.evaluate(predictions)
    
    dl_results.append((name, auc_score, aupr_score, acc_score, f1_score))


print(f"\n{'Model':<15} {'AUC':<8} {'AUPR':<8} {'Accuracy':<10} {'F1-Score':<8}")
print("-"*80)

for name, auc, aupr, acc, f1 in sorted(dl_results, key=lambda x: x[3], reverse=True):
    print(f"{name:<15} {auc:<8.4f} {aupr:<8.4f} {acc:<10.4f} {f1:<8.4f}")

print("="*80)


best_dl_model = max(dl_results, key=lambda x: x[3])
print(f"🏆 BEST DEEP LEARNING MODEL: {best_dl_model[0]} with {best_dl_model[3]:.2%} accuracy!")
