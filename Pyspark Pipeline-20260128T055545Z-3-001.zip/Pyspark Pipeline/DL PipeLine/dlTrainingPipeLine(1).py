from pyspark.ml.classification import MultilayerPerceptronClassifier


input_dim = len(feature_cols)
print(f"Input dimension: {input_dim}")


mlp_shallow = MultilayerPerceptronClassifier(
    featuresCol="scaled_features", 
    labelCol="target",
    layers=[input_dim, 10, 2], 
    maxIter=200,
    seed=42
)


mlp_medium = MultilayerPerceptronClassifier(
    featuresCol="scaled_features", 
    labelCol="target",
    layers=[input_dim, 20, 10, 2],  
    maxIter=200,
    seed=42
)


mlp_deep = MultilayerPerceptronClassifier(
    featuresCol="scaled_features", 
    labelCol="target",
    layers=[input_dim, 30, 20, 10, 2],  
    maxIter=250,
    seed=42
)


mlp_wide = MultilayerPerceptronClassifier(
    featuresCol="scaled_features", 
    labelCol="target",
    layers=[input_dim, 50, 25, 2],  
    maxIter=200,
    seed=42
)


mlp_very_deep = MultilayerPerceptronClassifier(
    featuresCol="scaled_features", 
    labelCol="target",
    layers=[input_dim, 25, 20, 15, 10, 2],  
    maxIter=300,
    seed=42
)

print("✅ All Deep Learning model architectures defined!")
