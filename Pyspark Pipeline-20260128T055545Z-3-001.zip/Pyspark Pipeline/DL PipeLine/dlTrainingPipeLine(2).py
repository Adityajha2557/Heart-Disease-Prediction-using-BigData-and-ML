print("🚀 Training all Deep Learning models...")

# Train all models
dl_models = {
    "MLP_Shallow": mlp_shallow.fit(train),
    "MLP_Medium": mlp_medium.fit(train), 
    "MLP_Deep": mlp_deep.fit(train),
    "MLP_Wide": mlp_wide.fit(train),
    "MLP_VeryDeep": mlp_very_deep.fit(train)
}

print("✅ All 5 Deep Learning models trained successfully!")
